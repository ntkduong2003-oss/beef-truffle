const BeefSupplyChain = artifacts.require("BeefSupplyChain");

module.exports = function (deployer) {
  deployer.deploy(BeefSupplyChain);
};
