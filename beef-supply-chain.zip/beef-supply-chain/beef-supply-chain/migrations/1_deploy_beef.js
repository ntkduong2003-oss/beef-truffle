const BeefSupplyChain = artifacts.require("BeefSupplyChain");
module.exports = function (deployer) {
  deployer.deploy(BeefSupplyChain); // msg.sender of deploy = owner
};
